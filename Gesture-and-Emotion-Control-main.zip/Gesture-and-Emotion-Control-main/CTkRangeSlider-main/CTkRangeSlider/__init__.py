"""
CTkRangeSlider
Range slider for customtkinter
Author: Akash Bora
"""

__version__ = '0.1'

from .ctk_rangeslider import CTkRangeSlider
